echo "Enter the number of directories to create:"
read n
for ((i=1; i<=$n; i++))
do
  mkdir "Directory_$i"
done 