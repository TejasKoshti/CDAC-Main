﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentConsole
{

    public class Student
    {
        public int RollNo { get; set; }
        public string Subject { get; set; }
        public int Marks { get; set; }
    }
}

