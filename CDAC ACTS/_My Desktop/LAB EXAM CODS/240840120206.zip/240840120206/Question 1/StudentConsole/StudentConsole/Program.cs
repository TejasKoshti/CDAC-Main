﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace StudentConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Student> students = new List<Student>();

            while (true)
            {
                Console.WriteLine("1. Add Student");
                Console.WriteLine("2. Save Data to File");
                Console.WriteLine("3. Display Data from File");
                Console.WriteLine("4. Connect to Database");
                Console.WriteLine("5. Exit");

                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        GetStudentInput(students);
                        break;
                    case 2:
                        SaveDataToFile(students);
                        break;
                    case 3:
                        DisplayDataFromFile();
                        break;
                    case 4:
                        ConnectToDatabase();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void GetStudentInput(List<Student> students)
        {
            Console.Write("Enter Roll No: ");
            int rollNo = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Subject: ");
            string subject = Console.ReadLine();

            Console.Write("Enter Marks: ");
            int marks = Convert.ToInt32(Console.ReadLine());

            Student student = new Student { RollNo = rollNo, Subject = subject, Marks = marks };
            students.Add(student);
        }

        static void SaveDataToFile(List<Student> students)
        {
            using (StreamWriter writer = new StreamWriter("students.txt"))
            {
                foreach (var student in students)
                {
                    writer.WriteLine($"{student.RollNo},{student.Subject},{student.Marks}");
                }
            }
        }

        static void DisplayDataFromFile()
        {
            if (File.Exists("students.txt"))
            {
                string[] lines = File.ReadAllLines("students.txt");
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    Console.WriteLine($"Roll No: {parts[0]}, Subject: {parts[1]}, Marks: {parts[2]}");
                }
            }
            else
            {
                Console.WriteLine("No data found in file.");
            }
        }



        static void ConnectToDatabase()
        {
            // Define the connection string
            string connectionString = "Server=myServer;Database=StudentConsole;User Id=myUser;Password=myPassword;";

            // Create the DbContext
            using (var context = new StudentConsoleContext(connectionString))
            {
                // Perform database operations
                var students = context.Students.ToList();

                foreach (var student in students)
                {
                    Console.WriteLine($"Roll No: {student.RollNo}, Subject: {student.Subject}, Marks: {student.Marks}");
                }
            }
        }
    }


}





