﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentConsole
{
    internal class DataAccess
    {
        private string connectionString = "Server=myServer;Database=myDatabase;User Id=myUser;Password=myPassword;";

        public void SaveDataToDatabase(List<Student> students)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                foreach (var student in students)
                {
                    string query = "INSERT INTO Students (RollNo, Subject, Marks) VALUES (@RollNo, @Subject, @Marks)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@RollNo", student.RollNo);
                    command.Parameters.AddWithValue("@Subject", student.Subject);
                    command.Parameters.AddWithValue("@Marks", student.Marks);
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<Student> GetDataFromDatabase()
        {
            List<Student> students = new List<Student>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM Students";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Student student = new Student
                    {
                        RollNo = reader.GetInt32(0),
                        Subject = reader.GetString(1),
                        Marks = reader.GetInt32(2)
                    };
                    students.Add(student);
                }
            }

            return students;
        }
    }
}