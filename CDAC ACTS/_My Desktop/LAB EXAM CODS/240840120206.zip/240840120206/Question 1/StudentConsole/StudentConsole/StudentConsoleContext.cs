﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using StudentConsole;

namespace StudentConsole
{

    public class StudentConsoleContext : IDisposable
    {
        public StudentConsoleContext(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public DbSet<Student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(connectionString);
        }
    }
}




