﻿using System;
using System.Collections.Generic;

namespace StudentsMVC.Models;

public partial class Student
{
    public int RollNo { get; set; }

    public string? Name { get; set; }

    public string? Marks { get; set; }

    public string? Subjects { get; set; }
}
